document.addEventListener("DOMContentLoaded", () => {
  
  const submitButton = document.querySelector(".submit-button")
  if (submitButton) {
    submitButton.addEventListener("click", (e) => {
      e.preventDefault()
      openSubmissionModal()
    })
  }

  
  initFilters()
})

function initFilters() {
  const searchInput = document.querySelector(".search-box input")
  const filterSelects = document.querySelectorAll(".filter-select")
  const projectCards = document.querySelectorAll(".project-card")

  
  if (searchInput) {
    searchInput.addEventListener("input", filterProjects)
  }

  
  filterSelects.forEach((select) => {
    select.addEventListener("change", filterProjects)
  })

  function filterProjects() {
    const searchTerm = searchInput ? searchInput.value.toLowerCase() : ""
    const ageFilter = filterSelects[0] ? filterSelects[0].value : ""
    const typeFilter = filterSelects[1] ? filterSelects[1].value : ""

    projectCards.forEach((card) => {
      const title = card.querySelector("h3").textContent.toLowerCase()
      const creator = card.querySelector(".creator").textContent.toLowerCase()
      const tags = Array.from(card.querySelectorAll(".tag")).map((tag) => tag.textContent.toLowerCase())

      
      const matchesSearch = title.includes(searchTerm) || creator.includes(searchTerm)
      const matchesAge = !ageFilter || creator.includes(ageFilter)
      const matchesType = !typeFilter || tags.some((tag) => tag.includes(typeFilter.toLowerCase()))

      
      if (matchesSearch && matchesAge && matchesType) {
        card.style.display = "block"
      } else {
        card.style.display = "none"
      }
    })
  }
}

function openSubmissionModal() {
  
  const modalOverlay = document.createElement("div")
  modalOverlay.className = "modal-overlay"

  
  const modalContent = document.createElement("div")
  modalContent.className = "modal-content"

  
  const modalHeader = document.createElement("div")
  modalHeader.className = "modal-header"
  modalHeader.innerHTML = `
        <h2>Submit Your Creation</h2>
        <button class="modal-close">&times;</button>
    `

  
  const modalBody = document.createElement("div")
  modalBody.className = "modal-body"
  modalBody.innerHTML = `
        <form id="project-submission-form">
            <div class="form-group">
                <label for="student-name">Your Name</label>
                <input type="text" id="student-name" name="student-name" required>
            </div>
            
            <div class="form-group">
                <label for="student-age">Your Age</label>
                <input type="number" id="student-age" name="student-age" min="5" max="15" required>
            </div>
            
            <div class="form-group">
                <label for="project-title">Project Title</label>
                <input type="text" id="project-title" name="project-title" required>
            </div>
            
            <div class="form-group">
                <label for="project-type">Project Type</label>
                <select id="project-type" name="project-type" required>
                    <option value="">Select a type</option>
                    <option value="Game">Game</option>
                    <option value="Animation">Animation</option>
                    <option value="Website">Website</option>
                    <option value="App">App</option>
                    <option value="Robot">Robotics</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="project-description">Project Description</label>
                <textarea id="project-description" name="project-description" rows="3" required></textarea>
            </div>
            
            <div class="form-group">
                <label>Project Screenshots (Up to 3 images)</label>
               <div class="screenshot-upload-container">
    <div class="screenshot-upload">
        <input type="file" id="screenshot-1" name="screenshots" accept="image/*" class="screenshot-input">
        <div class="upload-preview">
            <i class="fas fa-plus"></i>
            <span>Add Image</span>
        </div>
    </div>
    
    <div class="screenshot-upload">
        <input type="file" id="screenshot-2" name="screenshots" accept="image/*" class="screenshot-input">
        <div class="upload-preview">
            <i class="fas fa-plus"></i>
            <span>Add Image</span>
        </div>
    </div>
    
    <div class="screenshot-upload">
        <input type="file" id="screenshot-3" name="screenshots" accept="image/*" class="screenshot-input">
        <div class="upload-preview">
            <i class="fas fa-plus"></i>
            <span>Add Image</span>
        </div>
    </div>
</div>

            
            <div class="form-actions">
                <button type="button" class="btn cancel-btn">Cancel</button>
                <button type="submit" class="btn submit-btn">Submit Project</button>
            </div>
        </form>
    `

  
  modalContent.appendChild(modalHeader)
  modalContent.appendChild(modalBody)

  
  modalOverlay.appendChild(modalContent)

  
  document.body.appendChild(modalOverlay)

  
  setupModalInteractions(modalOverlay)

  
  setupImagePreviews()

  
  setTimeout(() => {
    modalOverlay.classList.add("active")
  }, 10)
}

function setupModalInteractions(modalOverlay) {
  
  const closeButton = modalOverlay.querySelector(".modal-close")
  if (closeButton) {
    closeButton.addEventListener("click", () => closeModal(modalOverlay))
  }

  
  const cancelButton = modalOverlay.querySelector(".cancel-btn")
  if (cancelButton) {
    cancelButton.addEventListener("click", () => closeModal(modalOverlay))
  }

  
  modalOverlay.addEventListener("click", (e) => {
    if (e.target === modalOverlay) {
      closeModal(modalOverlay)
    }
  })

  
  const form = modalOverlay.querySelector("#project-submission-form")
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault()
      handleFormSubmission(form, modalOverlay)
    })
  }
}

function setupImagePreviews() {
  const fileInputs = document.querySelectorAll(".screenshot-input")

  fileInputs.forEach((input) => {
    input.addEventListener("change", function (e) {
      const file = e.target.files[0]
      if (file) {
        const reader = new FileReader()
        const previewContainer = this.nextElementSibling

        reader.onload = (e) => {
          previewContainer.innerHTML = `
                        <img src="${e.target.result}" alt="Screenshot preview">
                        <button type="button" class="remove-image"><i class="fas fa-times"></i></button>
                    `

          
          const removeButton = previewContainer.querySelector(".remove-image")
          if (removeButton) {
            removeButton.addEventListener("click", () => {
              
              input.value = ""
              
              previewContainer.innerHTML = `
                                <i class="fas fa-plus"></i>
                                <span>Add Image</span>
                            `
            })
          }
        }

        reader.readAsDataURL(file)
      }
    })
  })
}

function handleFormSubmission(form, modalOverlay) {
  
  const formData = new FormData(form)

  
  

  
  const successMessage = document.createElement("div")
  successMessage.className = "submission-success"
  successMessage.innerHTML = `
        <i class="fas fa-check-circle"></i>
        <h3>Thank You!</h3>
        <p>Your project has been submitted successfully. Our team will review it and add it to the gallery soon.</p>
        <button class="btn close-success-btn">Close</button>
    `

  
  const modalBody = form.parentElement
  modalBody.innerHTML = ""
  modalBody.appendChild(successMessage)

  
  const closeButton = modalBody.querySelector(".close-success-btn")
  if (closeButton) {
    closeButton.addEventListener("click", () => closeModal(modalOverlay))
  }
}

function closeModal(modalOverlay) {
  
  modalOverlay.classList.remove("active")

  
  setTimeout(() => {
    document.body.removeChild(modalOverlay)
  }, 300)
}
