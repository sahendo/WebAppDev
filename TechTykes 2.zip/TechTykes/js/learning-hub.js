document.addEventListener("DOMContentLoaded", () => {
  
  const pathButtons = document.querySelectorAll(".path-button")
  const learningPaths = document.querySelectorAll(".learning-path")

  pathButtons.forEach((button) => {
    button.addEventListener("click", function () {
      const path = this.getAttribute("data-path")

      
      pathButtons.forEach((btn) => btn.classList.remove("active"))
      this.classList.add("active")

      
      learningPaths.forEach((learningPath) => {
        learningPath.classList.remove("active")
        if (learningPath.classList.contains(path + "-path")) {
          learningPath.classList.add("active")
        }
      })
    })
  })

  
  initCodePlayground()
})

function initCodePlayground() {
  const codeArea = document.querySelector(".code-area pre code")
  const previewArea = document.querySelector(".preview-area")
  const runButton = document.querySelector(".control-button.primary")
  const resetButton = document.querySelector(".control-button:not(.primary)")

  
  const canvas = document.createElement("canvas")
  canvas.width = 300
  canvas.height = 300
  canvas.style.border = "1px solid #e0e0e0"
  canvas.style.backgroundColor = "#f9f9f9"

  
  previewArea.innerHTML = ""
  previewArea.appendChild(canvas)

  const ctx = canvas.getContext("2d")

  
  let robot = {
    x: 150,
    y: 150,
    direction: 0, 
    size: 20,
  }

  
  drawRobot()

  
  codeArea.setAttribute("contenteditable", "true")
  codeArea.style.outline = "none"
  codeArea.style.minHeight = "150px"

  
  runButton.addEventListener("click", () => {
    
    resetRobot()

    
    const code = codeArea.textContent

    
    try {
      executeCode(code)
    } catch (error) {
      alert("Error: " + error.message)
    }
  })

  
  resetButton.addEventListener("click", () => {
    
    resetRobot()

    // Reset the code to default
    codeArea.textContent = "// Try changing the numbers!\nmoveForward(3);\nturnRight();\nmoveForward(2);"
  })

  function resetRobot() {
    robot = {
      x: 150,
      y: 150,
      direction: 0,
      size: 20,
    }
    drawRobot()
  }

  function drawRobot() {
    
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    
    ctx.strokeStyle = "#e0e0e0"
    ctx.lineWidth = 1

    
    for (let x = 0; x <= canvas.width; x += 30) {
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, canvas.height)
      ctx.stroke()
    }

    
    for (let y = 0; y <= canvas.height; y += 30) {
      ctx.beginPath()
      ctx.moveTo(0, y)
      ctx.lineTo(canvas.width, y)
      ctx.stroke()
    }

    
    ctx.save()
    ctx.translate(robot.x, robot.y)
    ctx.rotate((robot.direction * Math.PI) / 2)

    
    ctx.fillStyle = "#4a6bff"
    ctx.fillRect(-robot.size / 2, -robot.size / 2, robot.size, robot.size)

    
    ctx.fillStyle = "#ff6b6b"
    ctx.beginPath()
    ctx.moveTo(0, -robot.size / 2 - 10)
    ctx.lineTo(-5, -robot.size / 2)
    ctx.lineTo(5, -robot.size / 2)
    ctx.closePath()
    ctx.fill()

    ctx.restore()
  }

  function executeCode(code) {
    
    const moveForward = (steps = 1) => {
      steps = Number.parseInt(steps) || 1
      animateMovement(steps)
    }

    const turnRight = () => {
      robot.direction = (robot.direction + 1) % 4
      drawRobot()
    }

    const turnLeft = () => {
      robot.direction = (robot.direction + 3) % 4 
      drawRobot()
    }

    
    const safeCode = `
            ${code}
        `

    
    const executeFunction = new Function("moveForward", "turnRight", "turnLeft", safeCode)
    executeFunction(moveForward, turnRight, turnLeft)
  }

  function animateMovement(steps) {
    let currentStep = 0

    function step() {
      if (currentStep < steps) {
        
        switch (robot.direction) {
          case 0: 
            robot.y -= 30
            break
          case 1: 
            robot.x += 30
            break
          case 2: 
            robot.y += 30
            break
          case 3: 
            robot.x -= 30
            break
        }

        
        robot.x = Math.max(robot.size / 2, Math.min(canvas.width - robot.size / 2, robot.x))
        robot.y = Math.max(robot.size / 2, Math.min(canvas.height - robot.size / 2, robot.y))

        drawRobot()
        currentStep++

        
        setTimeout(step, 300)
      }
    }

    step()
  }
}
