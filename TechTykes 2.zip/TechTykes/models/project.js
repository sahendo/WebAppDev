const mongoose = require('mongoose');

const projectSchema = new mongoose.Schema({
  studentName: { type: String, required: true },
  age: { type: Number, required: true },
  projectTitle: { type: String, required: true },
  projectType: { type: String, required: true },
  projectDescription: { type: String, required: true },
  screenshots: [String],
  submissionDate: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Project', projectSchema);