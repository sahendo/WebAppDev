const path = require('path');

require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const Enrollment = require('./models/Enrollment');
const ContactMessage = require('./models/ContactMessage');
const Project = require('./models/project');
const VolunteerApplication = require('./models/volunteer');
const multer = require('multer');
const bodyParser = require('body-parser');

const app = express();
app.use(express.json());
app.use(cors());


app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));



const auth = async (req, res, next) => {
  try {
    const token = req.header('Authorization').replace('Bearer ', '');
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    if (decoded.role === 'admin') {
      req.user = { role: 'admin' };
      return next();
    }

    const enrollment = await Enrollment.findById(decoded.id);
    if (!enrollment) throw new Error();

    req.user = enrollment;
    req.token = token;
    next();
  } catch (error) {
    res.status(401).json({ error: 'Please authenticate' });
  }
};

app.post('/api/enroll', async (req, res) => {
  try {
    const {
      parentFirstName,
      parentLastName,
      parentEmail,
      parentPhone,
      parentAddress,
      parentCity,
      parentZip,
      emergencyContact,
      emergencyPhone,
      password,
      confirmPassword,
      termsAgree,
      photoRelease,
      newsletterSignup
    } = req.body;

    if (password !== confirmPassword) {
      return res.status(400).json({ error: 'Passwords do not match' });
    }

    const newEnrollment = new Enrollment({
      parentFirstName,
      parentLastName,
      parentEmail,
      parentPhone,
      parentAddress,
      parentCity,
      parentZip,
      emergencyContact,
      emergencyPhone,
      password,
      termsAgree,
      photoRelease,
      newsletterSignup
    });

    await newEnrollment.save();

    const token = jwt.sign({ id: newEnrollment._id }, process.env.JWT_SECRET);
    res.status(201).json({ token });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { email, password, role } = req.body;

    
    if (role === 'admin') {
      if (email === 'admin@gmail.com' && password === 'admin') {
        const token = jwt.sign(
          { role: 'admin' }, 
          process.env.JWT_SECRET,
          { expiresIn: '1h' }
        );
        return res.json({ token, user: { role: 'admin' } });
      }
      return res.status(401).json({ error: 'Invalid admin credentials' });
    }

    
    const enrollment = await Enrollment.findOne({ parentEmail: email });

    if (!enrollment || !await bcrypt.compare(password, enrollment.password)) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { id: enrollment._id, role: 'user' },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    res.json({
      token,
      user: {
        id: enrollment._id,
        email: enrollment.parentEmail,
        name: `${enrollment.parentFirstName} ${enrollment.parentLastName}`,
        role: 'user'
      }
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/admin/data', auth, (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  res.json({ secretData: 'Admin-only content' });
});

app.post('/contact', async (req, res) => {
  try {
    const { name, email, phone, subject, message } = req.body;

    const newMessage = new ContactMessage({
      name,
      email,
      phone,
      subject,
      message
    });

    await newMessage.save();
    res.status(201).json({ message: "Thank you for contacting us!" });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});


app.post('/api/volunteer', async (req, res) => {
    try {
        const newApplication = new VolunteerApplication(req.body);
        await newApplication.save();
        res.status(201).json({ message: 'Volunteer application submitted successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));


const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname);
  }
});

const upload = multer({ storage });


app.post('/projects', 
  upload.array('screenshots', 3), 
  async (req, res) => {
    try {
      
      console.log('Received files:', req.files);
      console.log('Received body:', req.body);

      const project = new Project({
        studentName: req.body.studentName,
        age: req.body.age,
        projectTitle: req.body.projectTitle,
        projectType: req.body.projectType,
        projectDescription: req.body.projectDescription,
        screenshots: req.files?.map(file => file.filename) || []
      });

      await project.save();
      res.status(201).json(project);
    } catch (error) {
      console.error('Save error:', error);
      res.status(400).json({ 
        error: error.message,
        stack: error.stack
      });
    }
  }
);
app.get('/projects', async (req, res) => {
  try {
    const projects = await Project.find().sort({ submissionDate: -1 });
    res.json(projects);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/enroll', async (req, res) => {
  try {
    const enrollments = await Enrollment.find();
    res.json(enrollments);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});
app.get('/api/volunteers', async (req, res) => {
  try {
    const volunteers = await VolunteerApplication.find() 
      .sort({ createdAt: -1 })
      .lean();
      
    res.json(volunteers);
  } catch (error) {
    console.error('Error fetching volunteers:', error);
    res.status(500).json({ 
      error: 'Internal server error',
      message: error.message
    });
  }
});
app.get('/api/projects', async (req, res) => {
  try {
    const projects = await Project.find()
      .sort({ submissionDate: -1 })
      .lean();
    
    console.log('Found projects:', projects.length);
    res.json(projects);
    
  } catch (error) {
    console.error('Project fetch error:', {
      message: error.message,
      stack: error.stack
    });
    res.status(500).json({ 
      error: 'Failed to load projects',
      details: error.message 
    });
  }
});
app.get('/api/messages', async (req, res) => {
    try {
        const messages = await ContactMessage.find()
            .sort({ createdAt: -1 })
            .lean();

        res.json(messages);
    } catch (error) {
        console.error('Error fetching messages:', error);
        res.status(500).json({ 
            error: 'Internal server error',
            message: error.message 
        });
    }
});
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
