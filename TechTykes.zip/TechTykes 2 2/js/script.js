document.addEventListener("DOMContentLoaded", () => {
  
  const navbarContainer = document.getElementById("navbar-container")
  const footerContainer = document.getElementById("footer-container")

  if (navbarContainer) {
    fetch("includes/navbar.html")
      .then((response) => response.text())
      .then((data) => {
        navbarContainer.innerHTML = data
        initMobileMenu()
      })
      .catch((error) => console.error("Error loading navbar:", error))
  }

  if (footerContainer) {
    fetch("includes/footer.html")
      .then((response) => response.text())
      .then((data) => {
        footerContainer.innerHTML = data
      })
      .catch((error) => console.error("Error loading footer:", error))
  }

  
  function initMobileMenu() {
    const mobileMenuToggle = document.querySelector(".mobile-menu-toggle")
    const navMenu = document.querySelector(".nav-menu")

    if (mobileMenuToggle && navMenu) {
      mobileMenuToggle.addEventListener("click", () => {
        navMenu.classList.toggle("active")
        mobileMenuToggle.setAttribute("aria-expanded", navMenu.classList.contains("active") ? "true" : "false")
      })
    }
  }

  
  const pathButtons = document.querySelectorAll(".path-button")
  const learningPaths = document.querySelectorAll(".learning-path")

  if (pathButtons.length > 0 && learningPaths.length > 0) {
    pathButtons.forEach((button) => {
      button.addEventListener("click", function () {
        const pathToShow = this.getAttribute("data-path")

        
        pathButtons.forEach((btn) => btn.classList.remove("active"))
        this.classList.add("active")

        
        learningPaths.forEach((path) => {
          path.classList.remove("active")
          if (path.classList.contains(pathToShow + "-path")) {
            path.classList.add("active")
          }
        })
      })
    })
  }

})
