
const mongoose = require('mongoose');

const VolunteerApplicationSchema = new mongoose.Schema({
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    email: { type: String, required: true },
    phone: { type: String, required: true },
    address: String,
    city: String,
    state: String,
    zip: String,
    roles: [String],
    availability: [String],
    skills: { type: String, required: true },
    why: { type: String, required: true },
    backgroundCheckAgreed: { type: Boolean, required: true },
}, { timestamps: true });

module.exports = mongoose.model('VolunteerApplication', VolunteerApplicationSchema);
