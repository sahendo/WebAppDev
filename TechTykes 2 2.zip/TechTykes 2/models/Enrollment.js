const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const enrollmentSchema = new mongoose.Schema({
  parentFirstName: { type: String, required: true },
  parentLastName: { type: String, required: true },
  parentEmail: { type: String, required: true, unique: true },
  parentPhone: { type: String, required: true },
  parentAddress: { type: String, required: true },
  parentCity: { type: String, required: true },
  parentZip: { type: String, required: true },
  emergencyContact: { type: String, required: true },
  emergencyPhone: { type: String, required: true },
  password: { type: String, required: true },
  newsletterSignup: { type: Boolean, default: false },
  termsAgree: { type: Boolean, required: true },
  photoRelease: { type: Boolean, required: true },
}, { timestamps: true });


enrollmentSchema.pre('save', async function (next) {
  if (this.isModified('password')) {
    this.password = await bcrypt.hash(this.password, 10);
  }
  next();
});

module.exports = mongoose.model('Enrollment', enrollmentSchema);
